package com.java.servlet;

public class crypt {

	public String encrypt(String password, String key) {
		// TODO Auto-generated method stub
		return null;
	}

}
